package main;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import control.Control;
import control.ControlDeVentanas;
import vista.VentanaConfiguracionConversor;

/**
 *
 * @author Jessel
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
           javax.swing.SwingUtilities.invokeLater(() -> {
               ControlDeVentanas cv=new ControlDeVentanas();
               /*Ventana AñadirMoneda fm = new VentanaAñadirMoneda(cf);
               fm.setVisible(true);*/
               Control control = new Control(cv);
               VentanaConfiguracionConversor conf =  cv.getConfig();
               
               conf.setVisible(true);
               /* VentanaPrincipal vp =  cf.getIntervG();
               
               fp.setVisible(true);*/
           });
    }
    
}
