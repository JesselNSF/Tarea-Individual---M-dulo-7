/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.ArrayList;

public class Conversor {

    private Moneda monedaBase;
    public static ArrayList<Moneda> listaMonedas = new ArrayList();

    public Conversor(Moneda monedaBase, Moneda otraMoneda) {
        this.monedaBase = monedaBase;

        listaMonedas.add(monedaBase);
        listaMonedas.add(otraMoneda);
    }

    public void setLlistaMonedes(Moneda moneda) {
        listaMonedas.add(moneda);
        Conversor.listaMonedas = listaMonedas;
    }

    public ArrayList<Moneda> getListaMonedas() {
        return listaMonedas;
    }

    
    public Conversor() {

    }

    public String getNomMonedaBase() {
        return this.monedaBase.getNom();
    }

    /**
     *
     * @param monedaOrigen
     * @param monedaDesti
     * @param cantidad
     * @return double
     */
    public double cambio(Moneda monedaOrigen, Moneda monedaDesti, double cantidad) {
        double cambio = ((cantidad * monedaOrigen.getValor()) / monedaDesti.getValor());
        return cambio;
    }

    /**
     *
     * @param monedaNueva
     */
    public boolean añadirMoneda(Moneda monedaNueva) {
        boolean añadir = false;
        for (int i = 0; i < this.getListaMonedas().size(); i++) {
            if(getListaMonedas().get(i).getNom().equals(monedaNueva.getNom())){
                añadir = true;
                break;
            }
        }
        if(añadir == false){
        listaMonedas.add(monedaNueva);
        }
        return añadir;
    }

    /**
     *
     * @param pos
     * @param moneda
     */
    public void ModificarMoneda(int pos, Moneda moneda) {
        listaMonedas.set(pos, moneda);
    }

    /**
     *
     * @param moneda
     */
    public void eliminarMoneda(Moneda moneda) {
        this.listaMonedas.remove(moneda);
    }
}
