/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;


import vista.VentanaAñadirMoneda;
import vista.VentanaConfiguracionConversor;
import vista.VentanaEliminarMoneda;
import vista.VentanaPrincipal;



/**
 *
 * @author Jesssel
 */
public class ControlDeVentanas {
    private VentanaConfiguracionConversor config;
    private VentanaPrincipal intervG;
    private VentanaAñadirMoneda am;
    private VentanaEliminarMoneda VEliminarMoneda;
    private Control control = new Control(this);

    public VentanaConfiguracionConversor getConfig() {
        if (config == null){
            config = new VentanaConfiguracionConversor(this, control);
        }
        return config;
    }

    public VentanaPrincipal getIntervG() {
        if (intervG == null){
           intervG = new VentanaPrincipal(this, control);
        }
        return intervG;
    }

    public VentanaAñadirMoneda getAm() {
        if (am == null){
            am = new VentanaAñadirMoneda(this, control);
        }
        return am;
    }
    public VentanaEliminarMoneda getVentanaEliminarMoneda(){
           if (VEliminarMoneda == null){
            VEliminarMoneda = new VentanaEliminarMoneda(this, control);
        }
        return VEliminarMoneda;
    }
    
}
