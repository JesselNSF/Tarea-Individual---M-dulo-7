/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import model.Conversor;
import model.Moneda;

/**
 *
 * @author Jessel
 */
public class Control implements ActionListener {

    private int cont = 0;
    private final ControlDeVentanas controlVentanas;

    public Control(ControlDeVentanas controlVentanas) {
        this.controlVentanas = controlVentanas;
    }

    private final Conversor conversor = new Conversor();

    @Override
    @SuppressWarnings("empty-statement")
    public void actionPerformed(ActionEvent ae) {
        //Borramos los elementos de los combobox
        if (cont == 0) {
            controlVentanas.getIntervG().getjComboBoxA().removeAllItems();
            controlVentanas.getIntervG().getjComboBox2().removeAllItems();

        }

        if (ae.getSource().equals(controlVentanas.getConfig().getjButtonAceptar())) {
            try {

                String monedaBase = (String) controlVentanas.getConfig().getjTFMonedaBase().getText();
                double valor = Double.parseDouble(controlVentanas.getConfig().getjTFValorMonedaBase().getText());
                Moneda moneda = new Moneda(monedaBase, valor);
                conversor.añadirMoneda(moneda);
                controlVentanas.getIntervG().setVisible(true);
                actualizarMonedasCombobox();
                controlVentanas.getConfig().setVisible(false);
                cont++;
            } catch (NumberFormatException e) {
                controlVentanas.getConfig().mensajeError();
                controlVentanas.getConfig().getjTFMonedaBase().setText("");
                controlVentanas.getConfig().getjTFValorMonedaBase().setText("");

            }

        } else if (ae.getSource().equals(controlVentanas.getConfig().getjButtonSalir())) {
            controlVentanas.getConfig().dispose();
            System.exit(0);
        } else if (ae.getSource().equals(controlVentanas.getConfig().getjButtonLimpiar())) {
            controlVentanas.getConfig().getjTFMonedaBase().setText("");
            controlVentanas.getConfig().getjTFValorMonedaBase().setText("");
        } else if (ae.getSource().equals(controlVentanas.getAm().getjButtonAñadirMoneda())) {

            try {

                String monedaBase = (String) controlVentanas.getAm().getjTextFieldNomMoneda().getText();
                double valor = Double.parseDouble(controlVentanas.getAm().getjTextFieldValorMoneda().getText());
                Moneda moneda = new Moneda(monedaBase, valor);
                if (conversor.añadirMoneda(moneda) == true) {
                    controlVentanas.getAm().mensajeError();
                } else {
                    controlVentanas.getIntervG().setVisible(true);
                    controlVentanas.getAm().mensajeConfirm();
                    controlVentanas.getAm().getjTextFieldNomMoneda().setText("");
                    controlVentanas.getAm().getjTextFieldValorMoneda().setText("");
                    actualizarMonedesCombobox();

                }
                cont++;
                controlVentanas.getAm().getjTextFieldNomMoneda().setText("");
                controlVentanas.getAm().getjTextFieldValorMoneda().setText("");
            } catch (NumberFormatException e) {
                controlVentanas.getConfig().mensajeError();
                controlVentanas.getAm().getjTextFieldNomMoneda().setText("");
                controlVentanas.getAm().getjTextFieldValorMoneda().setText("");

            }

        } else if (controlVentanas.getIntervG().getjMenuAñadirMoneda().equals(ae.getSource())) {
            controlVentanas.getAm().setVisible(true);
        } else if(ae.getSource().equals(controlVentanas.getAm().getjButtonTornar())){
            controlVentanas.getAm().dispose();
        }else if (controlVentanas.getIntervG().getjButtonCalcular().equals(ae.getSource())) {
            Moneda monedaOrigen = null;
            Moneda monedaDesti = null;
            try {
                double cantidad = Double.parseDouble(controlVentanas.getIntervG().getjTFCantidad().getText());

                String nomMonedaOrigen = (String) this.controlVentanas.getIntervG().getjComboBox2().getSelectedItem();
                String nomMonedaDesti = (String) this.controlVentanas.getIntervG().getjComboBoxA().getSelectedItem();

                for (int i = 0; i < conversor.getListaMonedas().size(); i++) {
                    if (nomMonedaOrigen.equals(nomMonedaDesti)) {
                        monedaOrigen = conversor.getListaMonedas().get(i);
                        monedaDesti = conversor.getListaMonedas().get(i);;
                    } else if (conversor.getListaMonedas().get(i).getNom().equals(nomMonedaOrigen)) {
                        monedaOrigen = conversor.getListaMonedas().get(i);
                    } else if (conversor.getListaMonedas().get(i).getNom().equals(nomMonedaDesti)) {
                        monedaDesti = conversor.getListaMonedas().get(i);
                    }
                }
                double resultat = conversor.cambio(monedaOrigen, monedaDesti, cantidad);
                DecimalFormat formatter = new DecimalFormat("#0.00");
                controlVentanas.getIntervG().getjTFCambio().setText(formatter.format(resultat) + "");
            } catch (NumberFormatException ex) {
                controlVentanas.getConfig().mensajeError();
                controlVentanas.getIntervG().getjTFCantidad().setText("");
                controlVentanas.getIntervG().getjTFCambio().setText("");
            }

        } else if (ae.getSource().equals(controlVentanas.getIntervG().getjMenuSalir2())) {
            controlVentanas.getIntervG().dispose();
            System.exit(0);
        } else if (ae.getSource().equals(controlVentanas.getIntervG().getjMenuItemEliminarMoneda())) {
            controlVentanas.getVentanaEliminarMoneda().setVisible(true);
        } else if (ae.getSource().equals(controlVentanas.getVentanaEliminarMoneda().getjButtonAceptarEliminarMoneda())) {
            String nom = controlVentanas.getVentanaEliminarMoneda().getjComboBoxEliminarMoneda().getSelectedItem().toString();
            Moneda moneda = null;
            for (int i = 0; i < conversor.getListaMonedas().size(); i++) {
                if (conversor.getListaMonedas().get(i).getNom().equals(nom)) {
                    moneda = conversor.getListaMonedas().get(i);
                    break;
                }
            }
            conversor.eliminarMoneda(moneda);

            controlVentanas.getVentanaEliminarMoneda().mensajeConfirmacion();
            controlVentanas.getVentanaEliminarMoneda().setVisible(false);
            actualitzarMonedesCombobox();

            controlVentanas.getIntervG().setVisible(true);
        } else if (ae.getSource().equals(controlVentanas.getVentanaEliminarMoneda().getjButtonCancelar())) {
            controlVentanas.getVentanaEliminarMoneda().setVisible(false);
        }

    }

    public void actualitzarMonedesCombobox() {
        controlVentanas.getIntervG().getjComboBox2().removeAllItems();
        controlVentanas.getIntervG().getjComboBoxA().removeAllItems();
        controlVentanas.getVentanaEliminarMoneda().getjComboBoxEliminarMonedas().removeAllItems();

        for (int i = 0; i < conversor.getListaMonedas().size(); i++) {

            controlVentanas.getIntervG().getjComboBoxA().addItem(conversor.getListaMonedas().get(i).getNom());
            controlVentanas.getIntervG().getjComboBox2().addItem(conversor.getListaMonedas().get(i).getNom());
            controlVentanas.getVentanaEliminarMoneda().getjComboBoxEliminarMonedas().addItem(conversor.getListaMonedas().get(i).getNom());

        }

    }

    private void actualizarMonedesCombobox() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private void actualizarMonedasCombobox() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
